"""Constants and configuration variables in one place."""

# City of Seattle Login
COS_LOGIN_URL = "https://login.seattle.gov"
COS_LOGIN_SUCCESS_TITLE = "City of Seattle Utility Services"
COS_LOGIN_TEXT = "Log In"
COS_LOGIN_USERNAME = "userName"
COS_LOGIN_PASSWORD = "password"
COS_LOGIN_ALERT = "notification-box-paragraph"
